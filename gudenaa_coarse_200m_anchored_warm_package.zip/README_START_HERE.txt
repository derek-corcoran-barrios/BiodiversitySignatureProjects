Anchored 200 m warm-start run
================================

Why this version
----------------
The previous hard-network solve reached its 24-hour limit without finding any
feasible incumbent (AMPL solve_result_num 472). This package assigns a complete,
independently checked feasible solution before Gurobi starts. Gurobi can improve
that solution and work on the optimality bound instead of beginning with no
usable network.

Where to put the files
----------------------
From the BiodiversitySignatureProjects project root:

  Biodiversity_coarse_patch_anchors.mod

  Optimization/gudenaa_coarse_200m/
    gudenaa_coarse_200m_anchored.dat
    gudenaa_coarse_200m_anchored_mip_start.run
    gudenaa_coarse_200m_anchored_warm.run

The model and data files in the package are byte-for-byte copies of the three
files supplied for checking. The two files ending in _mip_start.run and
_warm.run are new.

How to start it in AMPL
-----------------------
  cd "O:\Nat_Sustain-proj\_user\derekCorcoran_au687614\BiodiversitySignatureProjects";
  include "Optimization/gudenaa_coarse_200m/gudenaa_coarse_200m_anchored_warm.run";

What to check in the first Gurobi messages
------------------------------------------
Look for a message indicating that a user MIP start was loaded and produced an
incumbent. If Gurobi says the start was rejected, stop and retain the complete
message/log for diagnosis rather than running for six hours.

Run settings
------------
  alg:start = 1       pass assigned AMPL variable values to Gurobi
  lim:time = 21600    six-hour maximum
  mip:gap = 0.01      stop early if a one-percent relative gap is proved

The summary also records Gurobi's best bound, relative/absolute MIP gaps, and
solve time, so a time-limited solution can be reported transparently.

The run writes separate files whose names contain _anchored_warm_, including
selected cells and their assigned restoration land uses, active existing
patches, anchor roots, a solution summary, and the Gurobi log.

Validated starting solution
---------------------------
  Selected cells:             4007
  Restored area:              13089.04 ha
  Permitted restoration band: 13085.9526803711 to 13089.9526803711 ha
  Final nature area:          25003.0873196289 ha
  Anchor patch:               115953
  Root-collected area:        18154.85 ha

The selected cells, chosen land uses, activated patches, network connectivity,
component-specific flow bound, all flow balances, final-area requirement, and
minimum-network requirement were checked while creating the MIP start.
