# Biodiversity_coarse_patch_anchors.mod
#
# Coarse-grid biodiversity restoration model with exact eligible area per
# planning cell and current-nature patches represented as supernodes.
#
# Every selected restoration component must connect to an activated patch in
# AnchorPatches. Area from restoration cells and activated existing patches is
# routed to an anchor root, which must collect at least MinNetworkAreaHa.
# ExistingPatchAreaHa is counted once per activated patch, irrespective of the
# number of cell-patch contacts.

# ---- Planning units and actions -----------------------------------------

set Cells ordered;
set MustIncludeCells within Cells default {};

set Landuses;
set NatureLanduses within Landuses;
set ForestLanduses within NatureLanduses;
set WetLanduses within NatureLanduses;

# Only pairs listed here receive a binary land-use decision.
set AllowedActions within {NatureLanduses, Cells};

# Candidate-to-candidate rook adjacency; each undirected edge appears once.
set E within {Cells, Cells};

# Current-nature patches touching the retained coarse graph. AnchorPatches can
# equal ExistingPatches or be a smaller ecologically chosen subset.
set ExistingPatches;
set AnchorPatches within ExistingPatches;
set CellPatchEdges within {Cells, ExistingPatches};

# ---- Scores, areas, bounds, and policy flags ----------------------------

param BioDiversity {NatureLanduses, Cells} default 0;

# Exact restorable Agriculture + ProductionForest hectares represented by a
# coarse cell. This can be less than the nominal four hectares.
param RestorableAreaHa {Cells} > 0;

# Full national area of each connected existing patch, counted once.
param ExistingPatchAreaHa {ExistingPatches} > 0;

# Safe, component-specific flow bounds supplied by the R presolve. Every node
# in one potential graph component receives that component's maximum possible
# area: candidate area plus each linked existing patch once.
param ComponentMaxAreaCellHa {Cells} > 0;
param ComponentMaxAreaPatchHa {ExistingPatches} > 0;

# AllowedActions already implements these restrictions. The flags make them
# auditable and the checks protect against malformed data files.
param IsProductionForestCell {Cells} binary default 0;
param IsHighCarbonCell {Cells} binary default 0;

param CurrentNatureAreaHa >= 0;
param FinalNatureTargetHa > 0 default 25000;
param RestorationToleranceHa >= 0 default 4;
param MinNetworkAreaHa > 0 default 5000;

# Optional minimum restored area by destination type; zero disables it.
param MinRestorationAreaHa {NatureLanduses} >= 0 default 0;

param RestorationTargetHa :=
    FinalNatureTargetHa - CurrentNatureAreaHa;

set NetworkArcs within {Cells, Cells} :=
    E union setof {(i,j) in E} (j,i);

# ---- Defensive checks ---------------------------------------------------

check: card(Cells) > 0;
check: card(NatureLanduses) > 0;
check: card(AnchorPatches) > 0;
check: RestorationTargetHa > 0;
check: RestorationTargetHa <= sum {c in Cells} RestorableAreaHa[c];

check {c in Cells}: ComponentMaxAreaCellHa[c] >= MinNetworkAreaHa;
check {p in ExistingPatches}:
    ComponentMaxAreaPatchHa[p] >= MinNetworkAreaHa;

check {c in Cells}:
    sum {l in NatureLanduses: (l,c) in AllowedActions} 1 > 0;

check {(i,j) in E}: i <> j;
check {(i,j) in E}:
    abs(ComponentMaxAreaCellHa[i] - ComponentMaxAreaCellHa[j]) <= 1e-6;
check {(c,p) in CellPatchEdges}:
    abs(ComponentMaxAreaCellHa[c] - ComponentMaxAreaPatchHa[p]) <= 1e-6;
check {p in ExistingPatches}:
    sum {(c,q) in CellPatchEdges: q = p} 1 > 0;

check {(l,c) in AllowedActions: IsProductionForestCell[c] = 1}:
    l in ForestLanduses;

check {(l,c) in AllowedActions: IsHighCarbonCell[c] = 1}:
    l in WetLanduses;

# ---- Restoration decisions and objective -------------------------------

var LanduseDecision {(l,c) in AllowedActions} binary;
var Selected {c in Cells} binary;

maximize ConservationIndex:
    sum {(l,c) in AllowedActions}
        BioDiversity[l,c] * LanduseDecision[l,c];

subject to LinkSelectedToOneLanduse {c in Cells}:
    Selected[c]
    = sum {l in NatureLanduses: (l,c) in AllowedActions}
        LanduseDecision[l,c];

subject to FinalAreaLower:
    sum {c in Cells} RestorableAreaHa[c] * Selected[c]
    >= RestorationTargetHa;

subject to FinalAreaUpper:
    sum {c in Cells} RestorableAreaHa[c] * Selected[c]
    <= RestorationTargetHa + RestorationToleranceHa;

subject to MinimumRestorationArea {l in NatureLanduses}:
    sum {c in Cells: (l,c) in AllowedActions}
        RestorableAreaHa[c] * LanduseDecision[l,c]
    >= MinRestorationAreaHa[l];

subject to MustIncludeConstraint {c in MustIncludeCells}:
    Selected[c] = 1;

# ---- Anchored minimum-area networks -------------------------------------
#
# A selected cell creates RestorableAreaHa[c] units of flow and an activated
# existing patch creates ExistingPatchAreaHa[p] units. Flow may use selected
# cells and active patches only. It can leave the network only at an activated
# anchor root. Therefore every selected component must touch an anchor, and
# each root must collect at least MinNetworkAreaHa.

var PatchActive {p in ExistingPatches} binary;
var AnchorRoot {p in AnchorPatches} binary;
var AreaFlowHa {(i,j) in NetworkArcs} >= 0;
var CellToPatchFlowHa {(c,p) in CellPatchEdges} >= 0;
var PatchToCellFlowHa {(c,p) in CellPatchEdges} >= 0;
var CollectedAreaHa {p in AnchorPatches} >= 0;

subject to RootNeedsActiveAnchor {p in AnchorPatches}:
    AnchorRoot[p] <= PatchActive[p];

subject to AbsorbOnlyAtAnchorRoot {p in AnchorPatches}:
    CollectedAreaHa[p]
    <= ComponentMaxAreaPatchHa[p] * AnchorRoot[p];

subject to MinimumAreaAtAnchorRoot {p in AnchorPatches}:
    CollectedAreaHa[p] >= MinNetworkAreaHa * AnchorRoot[p];

subject to CellFlowNeedsSelectedOrigin {(i,j) in NetworkArcs}:
    AreaFlowHa[i,j] <= ComponentMaxAreaCellHa[i] * Selected[i];

subject to CellFlowNeedsSelectedDestination {(i,j) in NetworkArcs}:
    AreaFlowHa[i,j] <= ComponentMaxAreaCellHa[j] * Selected[j];

subject to CellToPatchNeedsSelectedCell {(c,p) in CellPatchEdges}:
    CellToPatchFlowHa[c,p]
    <= ComponentMaxAreaCellHa[c] * Selected[c];

subject to CellToPatchNeedsActivePatch {(c,p) in CellPatchEdges}:
    CellToPatchFlowHa[c,p]
    <= ComponentMaxAreaPatchHa[p] * PatchActive[p];

subject to PatchToCellNeedsSelectedCell {(c,p) in CellPatchEdges}:
    PatchToCellFlowHa[c,p]
    <= ComponentMaxAreaCellHa[c] * Selected[c];

subject to PatchToCellNeedsActivePatch {(c,p) in CellPatchEdges}:
    PatchToCellFlowHa[c,p]
    <= ComponentMaxAreaPatchHa[p] * PatchActive[p];

subject to PatchActivationNeedsSelectedContact {p in ExistingPatches}:
    PatchActive[p]
    <= sum {(c,q) in CellPatchEdges: q = p} Selected[c];

subject to CandidateCellAreaBalance {c in Cells}:
    RestorableAreaHa[c] * Selected[c]
    + sum {(i,j) in NetworkArcs: j = c} AreaFlowHa[i,j]
    + sum {(d,p) in CellPatchEdges: d = c} PatchToCellFlowHa[d,p]
    = sum {(i,j) in NetworkArcs: i = c} AreaFlowHa[i,j]
    + sum {(d,p) in CellPatchEdges: d = c} CellToPatchFlowHa[d,p];

subject to ExistingPatchAreaBalance {p in ExistingPatches}:
    ExistingPatchAreaHa[p] * PatchActive[p]
    + sum {(c,q) in CellPatchEdges: q = p} CellToPatchFlowHa[c,q]
    = sum {(c,q) in CellPatchEdges: q = p} PatchToCellFlowHa[c,q]
    + (if p in AnchorPatches then CollectedAreaHa[p] else 0);
